<?php

	function resultatFormuleScientifique($nombre1, $nombre2) {
		return $nombre1 + $nombre2;
	}

	// fichier non ferm� (pas de balise de fermeture php)
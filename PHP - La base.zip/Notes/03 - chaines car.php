<?php
	$mot = "Lorem ipsum sin dolori";
?>
<!DOCTYPE html>
<html lang="fr">
	<head>
		<title>Les chaînes</title>
		<meta charset="utf-8" />
	</head>
	<body>
		<h1>Mot : </h1>
		<div>Longueur : </div>
		<div>Position orem : </div>
		<div>Remplacer : </div>
		<div>Substring : </div>
	</body>
</html>







